"""Trabalhando com tipificação e **variaveis**"""

nome = "Caio" #string
sobrenome = "Comitre" # isso é um comentario e jamais será interpretado
idade=35
altura = 1.81 #float
bermuda = False #boolean

print(nome + " " + sobrenome + " tem " + str(idade) + " anos")
print(idade + 2)

textoVariasLinhas = '''
um linha
outra linha
'''
print(textoVariasLinhas)