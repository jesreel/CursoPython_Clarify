def saudacao(nome):
    return f"Olá, {nome}!"

def soma(a, b):
    return a + b
