import pytest

def test_soma():
    assert 1 + 1 == 2

def test_subtracao():
    assert 2 - 1 == 1

def test_divisao():
    assert 4 / 2 == 2

def test_multiplicacao():
    assert 2 * 2 == 4