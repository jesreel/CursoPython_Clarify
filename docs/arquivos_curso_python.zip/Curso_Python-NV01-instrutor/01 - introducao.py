print('Olá São Paulo')
#print('Caio "Super" Ross')
print( "Caio 'Super' Ross" )


# Isso é um comentario


'''
Isso é um comentario
de varias linhas
'''


print("Meu nome é: Caio.\nMeu curso é: Python")