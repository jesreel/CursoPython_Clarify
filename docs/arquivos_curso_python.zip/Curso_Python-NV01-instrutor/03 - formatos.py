"""Detalhando strings e usando formato"""

nomeCompleto = "Caio Python Ross"
inicio = 5
fim =  inicio + 6
print(nomeCompleto[inicio:fim])

nome = input("Qual seu nome?")
sobrenome = input("Qual seu sobrenome")
print("Seu nome completo é: " + nome + " " + sobrenome)

valor01 = input("Insira seu primeiro valor: ")
valor02 = input("Insira seu segundo valor: ")

valor01 = int(valor01)

print(valor01 + int(valor02))

valor01 = input("Insira seu primeiro valor: ")
valor01 = input("Insira seu Segundo valor: ")