import meu_modulo  # Importando o módulo que criamos

# Usando as funções definidas em meu_modulo
print(meu_modulo.saudacao("Clarify"))
print(meu_modulo.soma(3, 5))
